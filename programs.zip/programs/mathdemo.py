


import math
print(math.floor(3.4))  # 3
print(math.log(2))



import math as m
print(m.ceil(34.3))


from math import log    #( . is not required)
print(log(3))


from math import *
print(log(3))


import os














