

alist = [4,45,56,12,23,76,67,12,248,9]

print(alist)
print(alist[::-1])

print(alist[0:4])

# for loop
for value in alist:
    print(value)
    
# display elements in reverse order

for value in alist[::-1]:
    print(value)


alist = [4,45,56,12,23,76,67,12,248,9]

# adding element
alist.append(500)
print("after appending", alist)
alist.append(89)
print("after appending", alist)


# alist.insert(where to insert,what to insert)
# alist.insert(index,value)
alist.insert(3,54)
print('after inserting :',alist)


# multiple elements
alist.extend([98,23,67])
print("After appending:", alist)


#get count of a element
getcount = alist.count(12)
print(getcount)


# remove - if the element is known
alist.remove(45)
print("after removing", alist)

# remove with the help of index
alist.pop(3) # 3 is index
print("after removing", alist)


alist.remove(45)
print("after removing", alist)

# with condition - if existing then only remove it
if 45 in alist:
    alist.remove(45)
    print("after removing", alist)


# sort the list
alist.sort()
print('after sorting', alist)


# reversing the list
alist.reverse()
print('after reversing', alist)






print("initial list :",alist)
alist[0] =90
print("After replacing", alist)

# elements inside tuple cannot the modifed directly
atup = (10,45,43,4)
atup[0] =89
print('after replacing',atup)


# indirectly changes to be done to tuple
atup = (10,45,43,4)
#converting from tuple to list   - typecasting
alist = list(atup)
# making changes
alist.append(76)
# recovert back
atup = tuple(alist)
print('after replacing',atup)




info = [10,20,None,50]
print(info)
info.pop(2)
print(info)


if None in info :
    getindex = info.index(None)
    print(getindex)
    print("None exists")
else:
    print("None doesnt exist")




alist = [30,30,30,40,50]
alist.remove(30)
print(alist)

alist = [30,30,30,40,50]
getc = alist.count(30)      # 3
for val in range(0,getc):   # range(0,3)
    alist.remove(30)
    
print(alist)
    




