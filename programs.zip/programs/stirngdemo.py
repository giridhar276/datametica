
# slicing
name = "python programming"
# string[start:stop:step]
print(name)
print(name[0])
print(name[1])
print(name[0:5])
print(name[2:6])
print(name[::])
print(name[:])
print(name[-1])
print(name[0:17:2])
print(name[1:17:2])
print(name[-5:-2])   #mmi
print(name[::-1])



