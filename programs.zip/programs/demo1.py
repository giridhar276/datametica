


book  = {"chap1":10 , "chap2":20 ,"chap3":30, "chap1":1000 } 

print(book)


aset = {10,20,30,10,20,45,5765,752544,55425,54,545,343}

print(aset)