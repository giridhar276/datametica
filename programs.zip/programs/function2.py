
# default arguments
# function overloading

# fixed
# body
def display(a=0,b=0,c=0):
    print(a,b,c)

# calling function
display()
display(10)
display(10,20)
display(10,20,30)