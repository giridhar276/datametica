



alist = ["python","unix","scala"]

output = enumerate(alist)
#print(list(output))

info = dict()
for item in list(output):
    #print(item)
    info[item[0]] = item[1]

print(info)
    