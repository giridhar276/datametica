

#variable length args

def display(*data):
    #print(data)
    for val in data:
        print(val)


display(10,20,30,12,23,34,45,56,67,78,43,32,54,"python","java")