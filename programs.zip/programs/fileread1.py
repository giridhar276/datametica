# reading the file line by line
# fobj can be called as file handler or custor or pointer
fobj = open("customers.txt","r")
for line in fobj:
    # remove whitespaces if having any
    line = line.strip()
    print(line)
fobj.close()

##  using context manager
## file will be closed automatically
## context manager is used in db operations and alson network connection or server connection
with open("customers.txt","r") as fobj:
    for line in fobj:
        # remove whitespaces if having any
        line = line.strip()
        print(line)

## using readlines()
with open("customers.txt","r") as fobj:
    #print(fobj.readlines())
    for line in fobj.readlines():
        print(line)
        
# using read()    # not generally su
with open("customers.txt","r") as fobj:
    print(fobj.read())