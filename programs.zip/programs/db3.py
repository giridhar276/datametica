
#write a program to read realestate.csv and insert all the street and city columns to the database.

import os
import pymysql
import csv
try:
    # create connection
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='datametica')
    # define cursor
    cursor = db.cursor()
    
    filename = "realestate.csv"
    if os.path.isfile(filename) or os.path.getsize(filename) > 0 :
        with open(filename,"r") as fobj:
            #converting file object to csv object
            reader = csv.reader(fobj)
            for line in reader:
                street = line[0]
                city = line[1]
                # create query
                query = "insert into realestate values('{}','{}')".format(street,city)
           
                # execute query
                cursor.execute(query)
                #print(cursor.rowcount,"row updated")
        db.commit()

    else:
        print('Unable to open the file .. file not found..!!')
        
    db.close()
    

except pymysql.err.InterfaceError as err:
    print(err)
except pymysql.err.DatabaseError as err:
    print(err)
except pymysql.err.DataError as err:
    print(err)
except Exception as err:
    print(err)
    