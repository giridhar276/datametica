

from google.cloud import bigquery
import os


credentials_path = 'credentials.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path

client = bigquery.Client()

table_id = 'testing-341617.garden.realestate'


rows = [
        {'street':'miyapur','city':'hyderabad'},
        {'street':'mgroad','city':'bangalore'},
        
        ]

print("-------------------")
errors = client.insert_rows_json(table_id,rows)

if errors == [] :
    print('New rows have been added')
else:
    print(errors)