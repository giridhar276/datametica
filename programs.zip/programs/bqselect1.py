

from google.cloud import bigquery
import os


credentials_path = 'credentials.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path

client = bigquery.Client()
print(client)

query_job = client.query("SELECT * FROM garden.realestateinfo1")


results = query_job.result()
print(results)


for record in results:
    print(record)