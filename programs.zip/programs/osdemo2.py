


import os
for file in os.listdir():
    if file.endswith(".py"):
        print(file.ljust(20) ,  os.path.getsize(file),"bytes")