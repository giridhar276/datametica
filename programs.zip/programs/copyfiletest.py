# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 09:16:41 2022

@author: gsripath
"""


import sys
import os
import shutil
try:
    path = os.getcwd()
    print("Current working directory :", path)
    path= "C:\\Users\\gsripath\\Desktop\\programs\\source"
    os.chdir(path)
    destination = "C:\\Users\\gsripath\\Desktop\\programs\\destination"
    if os.path.isdir(destination):
        for file in os.listdir(path):
            shutil.copy(file,destination)
            print(file ,"copied to ", destination)
    else:
        print(destination , "doesn't exist")
except Exception as err:
    print(err)
    print(sys.exc_info())
