print("python programming")

print(1,2,3)
        
print("java","oracle")

val = 10
print(val)
print("value is",10)


name = "python programming"
# slicing
# string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:4])
print(name[4:8])
print(name[:])
print(name[::])
print(name[0:17])
print(name[0:17:1])
print(name[0:17:2])
print(name[0:17:3])
print(name[1:17:2])
print(name[-1])
print(name[-2])
print(name[-3:-1])
print(name[::-1])



print(name.upper())
print(name.lower())
print(name.startswith("p"))
print(name.startswith("z"))
print(name.endswith("qewr"))
print(name.split(" "))
print(name.replace("python","ruby"))

print(name.isupper())
print(name.islower())

aname = "  python "
print(len(aname))

print(len(aname.strip()))
print(aname.rstrip())
print(aname.lstrip())


print(name.count("p"))




# conditions

name = "python programming"


aname = "I love {} and {}"
print(aname.format("python","unix"))
print(aname.format(1,2))
print(aname.format('biryani','car'))




if name.startswith('p') :
    print("name starts with p")
    print('inside if')
    print('Still inside if')
else:
    print("name is starting with someother character")
    
    

name = "python programming"
#name = name.upper()
if name.isupper() :
    print("string is upper")
else:
    print("string is something else")
    
    


for val in range(1,10):
    print(val)

for val in range(1,10,2):
    print(val)
    
name = "python"
for char in name:
    print(char)
    
for c in "unix":
    print(c)


# output in single line
for c in "unix":
    print(c,end= " ")

print(1,2,3,"unix")
print(1,2,end = " ")
print(1,2,sep="     ")  
    
    
    
    
    



name = "python"

name[0] = "z"
print(name)

    
    
    









