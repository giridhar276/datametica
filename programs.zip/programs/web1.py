
import sys
import requests
from bs4 import BeautifulSoup

try:
    response = requests.get("https://www.techworldguru.com/")
    
    if response.status_code == 200 :
        
        html = response.text
        soup = BeautifulSoup(html, 'html.parser')
        for link in soup.find_all('a'):
            print(link.get('href'))
    else:
        print("Unable to access URL")
except Exception as err:
    print(err)
    print(sys.exc_info())