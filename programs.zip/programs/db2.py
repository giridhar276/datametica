


import pymysql

try:
    # create connection
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='datametica')
    # define cursor
    cursor = db.cursor()
    # create query
    query = "insert into realestate1 values('{}','{}')".format('Banjara Hills','Hyderabad')
    
   
    # execute query
    cursor.execute(query)
    db.commit()
    print(cursor.rowcount ,"row updated")
    db.close()
    

except pymysql.err.InterfaceError as err:
    print(err)
except pymysql.err.DatabaseError as err:
    print(err)
except pymysql.err.DataError as err:
    print(err)
except Exception as err:
    print(err)
    
