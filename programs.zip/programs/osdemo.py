
import os

import shutil

import time
import datetime
import dateutil



#os.unlink('languages2.txt')

#print(os.listdir())

for file in os.listdir():
    print(file)