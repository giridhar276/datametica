


#Write a Python program to read realestate.csv and display the count of an individual city.
### using csv library
import csv
citylist = []
try:    
    filename = 'realestate.csv'
    with open(filename,"r") as fread:
        # convert file object  To csv object( csv understable format)
        reader = csv.reader(fread)
        for line in reader:
            #print(line)
            citylist.append(line[1])
        
        for city in set(citylist):
            print(city.ljust(20) ,citylist.count(city),"times")
        
        print("Total count", len(set(citylist)))


except Exception as err :
    print('user defined error :','file not found')
    print(err)