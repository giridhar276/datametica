


# fixed arguments
def display(a,b):
    c = a + b
    print(c)

display(10,20)


# lambda is the replacement of single liner function
#lambda functions
# inline function
# nameless function
#Instead of calling to function body.. function will be replaced
#  in the calling function itself
# syntax
#functioname = lambda variables :expression
display = lambda x,y :x+y
print(display(10,20))

display = lambda x : x.upper()
print(display('python'))