
# fixed
# body
def display(a,b):
    c =a + b
    print(c)



# calling function
display(10,20)