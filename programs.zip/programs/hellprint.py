

'''
print(1,2)

print("hello","python")
'''

#print("single line comment)


# print("executable line")
# print(1,2)

print("hello","python")
print("java")

