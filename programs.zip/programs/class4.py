

class Employee:
    def __init__(self,name="default",age=0):
        self.name = name
        self.age = age
    def displayName(self):
        print("Employee's name :",self.name)        
        print("Employee's age  :", self.age)
# object creation or object initialization    


# If you invoke this program directly then the below condition becomes true
# if this program is imported in some other program , the below condition false
if __name__ == "__main__":

    emp1 = Employee("Rita",25)
    emp1.displayName()
        
    emp2 = Employee("Gita",26)
    emp2.displayName()
        
    emp3 = Employee()
    emp3.displayName()
        
    emp4 = Employee("Ram")
    emp4.displayName()
