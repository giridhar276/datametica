


import json
with open('employee_multiple.json','r') as fobj:
    # we are converting file object to json object
    data = json.load(fobj)
    
    for item in data['users']:
        output = list(item.values())
        output[0] = str(output[0])
        print(",".join(output))
    