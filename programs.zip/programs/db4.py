


import pymysql
import csv

try:
    # create connection
    fw = open('backup.csv','w')
    writer = csv.writer(fw)
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='datametica')
    # define cursor
    cursor = db.cursor()
    # create query
    query = "select * from realestate"
    # execute query
    cursor.execute(query)
    # fetch data
    for record in cursor.fetchall():
        #print(record)
        writer.writerow(record)
    # close the connection
    db.close()
    
except Exception as err:
    print(err)