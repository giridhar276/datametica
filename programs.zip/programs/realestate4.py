

#Write a Python program to read realestate.csv and
# display all the UNIQUE cities and the count of unique cities

cityset = set()
try:    
    filename = 'realestate.csv'
    with open(filename,"r") as fread:
        for line in fread:
            # just to remove whitespaces
            line = line.strip()
            #print(line)
            output = line.split(",")
            cityset.add(output[1])
        
        for city in cityset:
            print(city)
        
        print("Total count", len(cityset))


except Exception as err :
    print('user defined error :','file not found')
    print(err)





citydict = dict()
try:    
    filename = 'realestate.csv'
    with open(filename,"r") as fread:
        for line in fread:
            # just to remove whitespaces
            line = line.strip()
            #print(line)
            output = line.split(",")
            citydict[output[1]] = 1
        
        for city in citydict:
            print(city)
        
        print("Total count", len(citydict))


except Exception as err :
    print('user defined error :','file not found')
    print(err)







citylist = []
try:    
    filename = 'realestate.csv'
    with open(filename,"r") as fread:
        for line in fread:
            # just to remove whitespaces
            line = line.strip()
            #print(line)
            output = line.split(",")
            citylist.append(output[1])
        
        for city in set(citylist):
            print(city)
        
        print("Total count", len(set(citylist)))


except Exception as err :
    print('user defined error :','file not found')
    print(err)