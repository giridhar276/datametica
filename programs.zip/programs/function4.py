
def display(*arg):
    print(type(arg))
    for val in arg:
        print(val)

display(10,20,30,40,43,43,343,43,645,3,"unix")




def displayBook(**book):
    for key,vaue in book.items():
        print(key,value)



displayBook(chap1=10, chap2=20)