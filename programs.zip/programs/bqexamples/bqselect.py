

'''
from google.cloud import bigquery
import os


credentials_path = 'credentials.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path

client = bigquery.Client()


job_id, results = client.query('SELECT * FROM  garden.realestateinfo1  LIMIT 1000')

# Check if the query has finished running.
complete, row_count = client.check_job(job_id)

# Retrieve the results.
results = client.get_query_rows(job_id)


QUERY = (
    'SELECT name FROM testing-341617.garden.realestateinfo1 limit 1000 '
)
query_job = client.query(QUERY)  # API request
rows = query_job.result()  # Waits for query to finish

for row in rows:
    print(row.name)
'''

from google.cloud import bigquery
from google.oauth2 import service_account
credentials = service_account.Credentials.from_service_account_file('credentials.json')


project_id = 'testing-341617'
client = bigquery.Client(credentials= credentials,project=project_id)
print(client)



query_job = client.query("""
   SELECT *
   FROM garden.realestateinfo1
   """)

results = query_job.result()
print(results)
count = 0
for line in results:
    count = count + 1
    #print(line)
print(count)
# testing-341617:garden.realestateinfo1 












