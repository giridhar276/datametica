
from google.cloud import bigquery
import os

credentials_path = 'credentials.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path
client = bigquery.Client()

def create_table_clustered(table_id):

    # [START bigquery_create_table_clustered]


    # Construct a BigQuery client object.
    

    # TODO(developer): Set table_id to the ID of the table to create.
    # table_id = "your-project.your_dataset.your_table_name"

    schema = [
        bigquery.SchemaField("full_name", "STRING"),
        bigquery.SchemaField("city", "STRING"),
        bigquery.SchemaField("zipcode", "INTEGER"),
    ]

    table = bigquery.Table(table_id, schema=schema)
    table.clustering_fields = ["city", "zipcode"]
    table = client.create_table(table)  # Make an API request.
    print(
        "Created clustered table {}.{}.{}".format(
            table.project, table.dataset_id, table.table_id
        )
    )
    # [END bigquery_create_table_clustered]
    return table

print(create_table_clustered('testing-341617.employeeinfo.realestate2'))