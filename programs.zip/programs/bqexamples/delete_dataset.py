from google.cloud import bigquery
import os


credentials_path = 'credentials.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path

client = bigquery.Client()

def delete_dataset(dataset_id):

    # [START bigquery_delete_dataset]

    from google.cloud import bigquery

    # Construct a BigQuery client object.
    client = bigquery.Client()

    # TODO(developer): Set model_id to the ID of the model to fetch.
    # dataset_id = 'your-project.your_dataset'

    # Use the delete_contents parameter to delete a dataset and its contents.
    # Use the not_found_ok parameter to not receive an error if the dataset has already been deleted.
    client.delete_dataset(
        dataset_id, delete_contents=True, not_found_ok=True
    )  # Make an API request.

    print("Deleted dataset '{}'.".format(dataset_id))
    # [END bigquery_delete_dataset]
    
    
    
delete_dataset('garden')