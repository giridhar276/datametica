

from google.cloud import bigquery
import os


credentials_path = 'mycredentials.json'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path

client = bigquery.Client()
print(client)


query_job = client.query("SELECT * FROM empinfo.realestate")

results = query_job.result()
#print(results)

for record in results:
    print(record)
