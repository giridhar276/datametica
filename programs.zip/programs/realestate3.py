


try:    
    filename = 'realestate.csv'
    with open(filename,"r") as fread:
        for line in fread:
            # just to remove whitespaces
            line = line.strip()
            #print(line)
            output = line.split(",")
            print("Street :",output[0])
            print("City   :",output[1])

except Exception as err :
    print('user defined error :','file not found')
    print(err)
