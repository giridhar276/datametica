'''
Write a Python program to display all the files and folders separately and its count also.

files
------
file1
file2
Total no. of files : 504

directories
------------
dir1
dir2
Total no. of direcotires : 453
'''

import os
filelist = []
dirlist = []
for file in os.listdir():
    if os.path.isfile(file):
        filelist.append(file)
    elif os.path.isdir(file):
        dirlist.append(file)
        
## display only files
for file in filelist:
    print(file)
print("Count of all the files :",len(filelist))
print("***********************************")
for adir in dirlist:
    print(adir)
print("Directories count :", len(dirlist))



        