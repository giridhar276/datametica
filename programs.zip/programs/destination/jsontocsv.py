



import json
with open('employee_multiple.json','r') as fobj:
    with open('output.csv','w') as fw:
        # we are converting file object to json object
        data = json.load(fobj)
        
        for item in data['users']:
            output = list(item.values())
            output[0] = str(output[0])
            fw.write(",".join(output) + "\n")
    
    
