
###### regular way to open the file
# opening the file
fobj = open("languages.txt","w")
fobj.write('java\n')
fobj.write('oracle')
# close the file
fobj.close()




### context manager
# any line starting with keyword with is called as context manager
# Advantage : the file will be closed automatically
with open('languages2.txt',"w") as fobj :
    fobj.write('unix programming\n')
    fobj.write('hadoop\n')

    

### saving the path in different path
#with open('D:\\new\\demo\\languages5.txt',"w") as fobj :
#with open(r'D:\new\demo\languages5.txt',"w") as fobj :
#with open('D:/new/demo/languages5.txt',"w") as fobj :
with open('D:\\languages5.txt',"w") as fobj :
    for val in range(1,10):
        fobj.write(str(val) + "\n")
    



