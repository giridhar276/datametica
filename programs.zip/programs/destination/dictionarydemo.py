
# dictionary

book = {"chap1":10 ,"chap2":20 ,"chap3":30}

print(book)

#print(book[0])
print(book["chap1"]) #10

# only keys
print(book.keys())

# only values
print(book.values())

#  [(k,v),(k,v),(k,v)]
print(book.items())


#print(book["chap4"])

# If some key is not available it returns None
# if available it willr return the values
print(book.get("chap4"))
print(book.get("chap1"))

if "chap5" in book:
    print(book['chap5'])
else:
    print('not existing..!!')


# for loop
print(book)
# only keys
for key in book.keys():
    print(key)
    

# only values
for val in book.values():
    print(val)
    
    
# display k,v both

for k,v in book.items():
    print(k,v)
    


# to check whether some key is existing or not

if 'chap1' in book:
    print("key exists...!!!")
else:
    print("key doesnt exist..!!")




def last(n): 
    #print(n)
    return n[-1]

def sort_list_last(tuples):
  return sorted(tuples, key=last)

print(sort_list_last([(2, 5), (1, 2), (4, 4), (2, 3), (2, 1)]))