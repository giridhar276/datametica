

# fixed arguments
def display(a,b):
    c = a + b
    print(c)


display(10,20)