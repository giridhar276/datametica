#context manager
# fread can be called as file cursor or file handler or pointer
with open("languages2332.txt","r") as fread:
    for line in fread:
        # just to remove whitespaces
        line = line.strip()
        print(line)
        
        
# display the strings present in the first line      
# fread can be called as file cursor or file handler or pointer
with open("languages.txt") as fread:
    for line in fread:
        # just to remove whitespaces
        line = line.strip()
        #print(line)
        output = line.split(",")
        print(output[0])
                
        
## display lines containing shell only
# fread can be called as file cursor or file handler or pointer
with open("languages.txt") as fread:
    for line in fread:
        # just to remove whitespaces
        line = line.strip()
        #print(line)
        if 'shell' in line:
            print(line)