



# keyword arguments
def display(b,a):
    print(a,b)


display(a=10,b=20)



print(10,20,sep='   ',end="\n")
print(30)


print(10,20,end="\n",sep='   ')
print(30)