


name = "python"

print(type(name))


if isinstance(name,str):
    print("Yes.. it is string")
else:
    print("someother object")
    
    
alist = [10,20,30]
print(isinstance(alist,dict))

print(len(alist))

print(max(alist))
print(min(alist))
print(sum(alist))