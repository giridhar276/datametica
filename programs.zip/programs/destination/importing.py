

# importing all the methods
import math
print(math.sin(2))
print(math.floor(45.4))


# importing library with alias name
import math as m
print(m.sin(2))
print(m.floor(45.4))
print(m.tan(2))


# importing required methods ONLY
# . is not required
from math import log,sin,tan
print(log(2))
print(tan(2))