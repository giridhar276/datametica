
try:    
    filename = input("Enter any filename :")
    with open(filename,"r") as fread:
        for line in fread:
            # just to remove whitespaces
            line = line.strip()
            print(line)
    #output = "hello" + 4
    book = {"chap1":10}
    print(book["chap5"])
except FileNotFoundError as err:
    print('File not found..!!')
    print(err)
except TypeError as err:
    print('Invalid operation')
    print(err)
except IndexError as err:
    print("Index is not available...")
    print(err)
except Exception as err :
    print('Error found')
    print(err)