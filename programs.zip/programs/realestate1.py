


# fread can be called as file cursor or file handler or pointer

try:    
    filename = input("Enter any filename :")
    with open(filename,"r") as fread:
        for line in fread:
            # just to remove whitespaces
            line = line.strip()
            print(line)
    output = "hello" + 4
except Exception as err :
    print('user defined error :','file not found')
    print(err)


