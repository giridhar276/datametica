


# single line comment
#print("python programming")


#multi line comment
'''
print(1,2,3)

print("java","oracle")
'''
